# -*- coding: utf-8 -*-
"""
Created on Fri Oct 18 19:30:30 2019

@author: Eastwind
"""

#from keras.models import Sequential
import matplotlib.pyplot as plt
import numpy as np
import random as rd
import data_ingestion as di
from sklearn.ensemble import RandomForestClassifier
from sklearn.datasets import make_classification
from sklearn import metrics
from sklearn.model_selection import train_test_split

#if __name__ == "__main__":
#    data = []
#    filename = 
#    with open(filename) as tsv:        
#        for line in csv.reader(tsv, delimiter=","):
#            data.appen
#            print(line)

def f_measure(H,Y):
    TP = 0
    TN = 0
    FN = 0
    FP = 0
    for i in range(0,len(H)):
        if(Y[i]==1 and H[i]==1):
            TP+=1 
        if(Y[i]==0 and H[i]==0):
            TN+=1 
        if(Y[i]==0 and H[i]==1):
            FN+=1
        if(Y[i]==1 and H[i]==0):
            FP+=1
    pre = TP/(TP+FP)
    rec = TP/(TP+FN)
    return (2*pre*rec)/(pre+rec)

#Parse a data file and return the features and labels as a numpy ndarray
features,labels = di.parse_data_file('arrhythmia.csv') 

#Calculate missing valeus and subsitute into missing field
feats,pop = features.shape
X = np.zeros((9,feats))
for i in np.arange(0,9):
    X[i] = features.T[i]

X= np.array(X).T

X_shape = X.shape

#Get a test and test tests at a 10/90 split. 
X_train, X_test, Y_train, Y_test = train_test_split(X, labels, test_size=0.3, random_state=0)

classifer = RandomForestClassifier(n_estimators=15, max_depth=10,random_state=0)
classifer.fit(X_train, Y_train)
hypo = classifer.predict(X_train)
print(hypo)
print(Y_train)
#score0 = f_measure(hypo, Y_train)
#hypo = classifer.predict(X_test)
#score1 = f_measure(hypo,Y_test)
#print('Train F-Measure: %f' % score0)
#print('Test F-Measure: %f' % score1)

